//
//  FoodDataCellCollectionViewCell.swift
//  MealSavvy
//
//  Created by AppsInvo Mac Mini 2 on 07/08/18.
//  Copyright © 2018 AppsInvo. All rights reserved.
//

import UIKit

class FoodDataCellCollectionViewCell: UICollectionViewCell {
    
}
