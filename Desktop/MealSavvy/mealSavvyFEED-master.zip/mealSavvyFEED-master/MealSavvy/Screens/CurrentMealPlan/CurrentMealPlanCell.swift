//
//  CurrentMealPlanCell.swift
//  MealSavvy
//
//  Created by AppsInvo Mac Mini 2 on 13/08/18.
//  Copyright © 2018 AppsInvo. All rights reserved.
//

import UIKit

class CurrentMealPlanCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
