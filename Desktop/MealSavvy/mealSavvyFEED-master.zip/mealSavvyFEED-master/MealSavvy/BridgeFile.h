//
//  BridgeFile.h
//  MealSavvy
//
//  Created by AppsInvo Mac Mini 2 on 08/08/18.
//  Copyright © 2018 AppsInvo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BridgeFile : UIViewController

@end
