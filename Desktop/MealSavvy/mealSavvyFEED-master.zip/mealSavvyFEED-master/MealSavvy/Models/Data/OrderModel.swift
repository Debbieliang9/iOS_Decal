//
//  OrderModel.swift
//  MealSavvy
//
//  Created by iOS Developer on 10/11/18.
//  Copyright © 2018 AppsInvo. All rights reserved.
//

import Foundation
